import spacing from '../../_data/spacing/spacing.json';

export default spacing;
