import fontWeight from '../../_data/font/font-weight.json';

export default fontWeight;
